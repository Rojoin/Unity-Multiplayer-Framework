﻿public enum GameState
{
    WaitingForPlayers,
    CooldownUntilStart,
    GameHasStarted
}